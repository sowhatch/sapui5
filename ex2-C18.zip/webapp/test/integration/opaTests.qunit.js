/* global QUnit */

sap.ui.require(["sync/c18/ex2/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
