/* global QUnit */

sap.ui.require(["sync/c18/ex3/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
