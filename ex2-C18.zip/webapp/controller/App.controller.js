sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("sync.c18.ex2.controller.App", {
        onInit() {
        }
      });
    }
  );
  